#include "1.c"
#include "2.c"
#include "3.c"
#include "4.c"
#include "5.c"
#include "6.c"
#include "7.c"
#include "8.c"
#include "9.c"
#include "10.c"
#include "11.c"
#include "12.c"
#include "13.c"
#include "14.c"

//escopo das funções de cada exercício

int questao1();
int questao2();
int questao3();
int questao4();

int calculaFatorial(int val);
int questao5();

int descobreMaior(int val1, int val2, int val3);
int questao6();

int descobreMenor(int val1, int val2, int val3);
int questao7();

void descobreMaiorEMenor(int vet[], int res[]);
int questao8();

int calculaDelta(int a, int b, int c);
int questao9();

void calculaEqSegGrau(int a, int b, int c, float vet[]);
int questao10();

float calculaExponencial(float x, float y);
int questao11();

float calculaPiAprox(int prec);
int questao12();

int calculaSomatorio(int inicio, int final);
int questao13();

int encontraMaior(int vet[]);
int questao14();

