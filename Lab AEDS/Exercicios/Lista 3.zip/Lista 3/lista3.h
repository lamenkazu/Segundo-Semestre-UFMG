#include "1.c"
#include "2.c"
#include "3.c"

int questao1();
int questao2();
void encontraMaior(int vet[]);
int questao3();