#include <stdio.h>
#include "lista3.h"
#define OK 0

int main(int argc, char ** argv){

    int op;

    do{
        printf("Lista de exercicios 3 - Erick Etiene\nEscolha o exercicio (1 a 18) para rodar: ");
        scanf("%d", &op);

        switch(op){
            case 1: questao1(); 
            break;
            case 2: questao2(); 
            break;
            case 3: questao3(); 
            break;
        }


    }while(op != 0);

    return OK;
}