#include "1.1.c"
#include "1.9.c"
#include "2.1.c"
#include "3.2.c"
#include "3.5.c"
#include "4.1.c"
#define OK 0

void questao1_1();

void questao1_9();

void questao2_1();

void questao3_2();

void questao3_5();

void questao4_1();