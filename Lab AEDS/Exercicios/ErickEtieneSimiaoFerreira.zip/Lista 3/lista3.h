#include "1.c"
#include "2.c"
#include "3.c"
#include "4.c"
#include "5.c"
#include "6.c"
#include "7.c"
#include "8.c"
#include "9.c"
#include "10.c"
#include "11.c"
#include "12.c"

int questao1();
int questao2();
void encontraMaior(int vet[]);
int questao3();

void encontraMaiorBin(int vet[]);
int questao4();

void ordenaIntAsc(int vet[]);
int questao5();

void ordenaIntAscBin(int vet[]);
int questao6();

void ordenaIntBin(int vet[]);
int questao7();

void ordenaIntTxt(int vet[]);
int questao8();

int questao9();

int verificaArquivosBin(FILE * arqBin1, FILE * arqBin2);
int questao10();

int questao11();
int questao12();